How to contribute
=================





http://tbaggery.com/2008/04/19/a-note-about-git-commit-messages.html
