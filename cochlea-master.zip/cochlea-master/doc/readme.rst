
.. toctree::
   :maxdepth: 2


.. include:: ../README.rst
   :start-after: GNU General Public License v3 or later (GPLv3+)
