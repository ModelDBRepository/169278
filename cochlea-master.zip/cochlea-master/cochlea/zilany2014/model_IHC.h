void IHCAN(double *px, double cf, int nrep, double tdres, int totalstim,
	   double cohc, double cihc, int species, double *ihcout);
